--  find the total quantity of each pizza category ordered.

select sum(od.quantity) as totalqty,pt.category from pizza_types pt
join pizzas p on pt.pizza_type_id=p.pizza_type_id
join order_details od on p.pizza_id=od.pizza_id
group by pt.category
order by totalqty desc;


-- Determine the distribution of orders by hour of the day.
select hour(order_time) ,count(1)as no_of_orders from orders
group by hour(order_time);


-- find the category-wise distribution of pizzas.
SELECT 
    category, COUNT(name) AS cnt
FROM
    pizza_types
GROUP BY category
ORDER BY cnt DESC;



-- calculate the average number of pizzas ordered per day.
with order_qty as (
  select o.order_date,sum(od.quantity) as total_order_qty from order_details od
  join orders o on od.order_id=o.order_id
  group by o.order_date),
  avg_qty as (
   select round(avg(total_order_qty),0) Avg_qty from order_qty)
   select * from avg_qty;



-- top 3 most ordered pizza types based on revenue.
with top_pizza as (
 SELECT 
    pt.name, ROUND(SUM(p.price * od.quantity), 0) AS revenue
FROM
    pizzas p
        JOIN
    pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
GROUP BY pt.name),
rank_pizzatype as (
    select *,
    rank() over(order by revenue desc) as rnk_revenue
    from top_pizza)
  select * from rank_pizzatype
  where rnk_revenue<=3;
 