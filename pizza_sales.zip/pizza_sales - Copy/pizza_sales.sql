
use pizza_sales;

-- data cleaning
describe orders;

update orders set order_date=str_to_date(order_date,'%d-%m-%Y')

alter table orders
modify column order_date date;

alter table orders
change column time order_time text;

update orders set order_time =str_to_date(order_time,'%H:%i:%s');

alter table orders
modify column order_time  time;

describe order_details;


-- total orders
select  count(distinct order_id) as TotalOrders from orders;

-- total revenue
select round(sum(p.price*od.quantity),0) as Revenue from pizzas p
join order_details od on p.pizza_id=od.pizza_id;

-- total qty
select sum(quantity) as TotalQty from order_details;


-- which pizza sold the most in totals revenue and qty?
SELECT 
   pt.name,
    round(SUM(p.price * od.quantity),0) AS TotalRevenue,
    sum(od.quantity) as totalqty
FROM
    pizzas p
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
        JOIN
    pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
GROUP BY pt.name
ORDER BY TotalRevenue DESC
LIMIT 1;


-- total sales on weekday and weekend

SELECT 
    CASE
        WHEN DAYOFWEEK(o.order_date) IN (1 , 7) THEN 'weekend'
        ELSE 'weekday'
    END AS day_of_week,
    SUM(p.price * od.quantity) AS revenue
FROM
    pizzas p
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
        JOIN
    orders o ON od.order_id = o.order_id
GROUP BY day_of_week;
   

-- what is the total revenue by month?
SELECT 
     monthname(order_date) as month,
     round(sum(p.price * od.quantity),0) AS Total 
FROM
    pizzas p
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
        JOIN
   orders o ON od.order_id=o.order_id
   group by monthname(order_date) 
   order by Total desc;
    
    -- Identify the most common pizza size ordered.
SELECT 
    p.size, COUNT(DISTINCT o.order_id) AS cnt
FROM
    pizzas p
        JOIN
    order_details o ON p.pizza_id = o.pizza_id
GROUP BY p.size
ORDER BY cnt DESC;

-- Identify the highest-priced pizza.
SELECT 
    pizzas.price, pt.name
FROM
    pizzas
        JOIN
    pizza_types pt ON pizzas.pizza_type_id = pt.pizza_type_id
ORDER BY pizzas.price DESC
LIMIT 1;


--  List the top 5 most ordered pizza types along with their quantities

 SELECT 
    pt.name, SUM(od.quantity) AS totalqty
FROM
    pizza_types pt
        JOIN
    pizzas p ON pt.pizza_type_id = p.pizza_type_id
        JOIN
    order_details od ON p.pizza_id = od.pizza_id
GROUP BY pt.name
ORDER BY totalqty DESC
LIMIT 5;